#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include "game.h"

int main( int argc, char* args[] )
{
    srand((unsigned int)time(NULL));
    atexit(Shutdown);
    if(!Initialize())
    {
        exit(1);
    }

    bool quit = false;
    SDL_Event event;

    Uint32 lastTick = SDL_GetTicks();

    while(!quit)
    {
        while(SDL_PollEvent(&event))
        {
            if(event.type == SDL_QUIT)
            {
                quit=true;
            }
        }
        Uint32 curTick = SDL_GetTicks();
        Uint32 diff = curTick - lastTick;
        float elapsed = diff / 1000.0f;
        Update(elapsed);
        lastTick = curTick;
    }



    SDL_Quit();
}
