#ifndef GAME_H_INCLUDED
#define GAME_H_UCLUDED

//kullan�lan k�t�phaneler
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdbool.h>
// temel tan�mlar burada yap�ld�
const int WIDTH = 440;
const int HEIGHT = 640;
const int BALL_SIZE = 10;
int renk9 = 255;
int renk8 = 255;
int renk7 = 255;
int renk6 = 255;
int renk5 = 255;
int renk4 = 255;
int renk3 = 255;
int renk2 = 255;
int renk1 = 255;
//structer �eklinde yap�lar�n �zellikleri
void breaker(void);
typedef struct Ball{
    float x;
    float y;
    float xSpeed;
    float ySpeed;
    int size;
}Ball;
typedef struct Brick{
    float xPosition;
} Brick;
const int BRICK_WIDTH = 100;
const int BRICK_HEIGHT = 30;
const int BRICK_MARGIN = 20;
typedef struct Player{
    int score;
    float xPosition;
} Player;
const int PLAYER_WIDTH = 75;
const int PLAYER_HEIGHT = 20;
const int PLAYER_MARGIN = 20;

const float PLAYER_MOVE_SPEED = 200.0f;

bool served = false;

Ball ball;

Player player1;

Brick brick1;
Brick brick2;
Brick brick3;
Brick brick4;
Brick brick5;
Brick brick6;
Brick brick7;
Brick brick8;
Brick brick9;

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;
// fonksiyonlar
bool Initialize(void);
void Update(float);
void Shutdown(void);

Ball MakeBall(int size);
void UpdateBall(Ball *ball, float elapsed);
void RenderBall(const Ball*);

Player MakePlayer(void);
void UpdatePlayers(float elapsed);
void RenderPlayers(void);

Brick MakeBrick(void);
void UpdateBrick(float elapsed);
void RenderBrick(void);

void UpdateScore(int player, int points);



bool Initialize(void)
{
        if(SDL_Init(SDL_INIT_VIDEO)!=0)
    {
        fprintf(stderr,"Failed to initialize SDL: %s\n", SDL_GetError());
        return false;
    }
    window = SDL_CreateWindow("Brick Breaker (click space)",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,WIDTH,HEIGHT, SDL_WINDOW_SHOWN);
    if(!window)
    {
        return false;
    }



    renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if(!window)
    {
        return false;
    }
    ball = MakeBall(BALL_SIZE);
    player1 = MakePlayer();
    brick1 = MakeBrick();
    brick2 = MakeBrick();
    return true;

}
// g�ncellemelerin yap�ld��� k�s�m
void Update(float elapsed)
{
    SDL_SetRenderDrawColor(renderer,0,0,0,255);
    SDL_RenderClear(renderer);


    UpdatePlayers(elapsed);
    RenderPlayers();

    UpdateBrick(elapsed);
    RenderBrick();

    UpdateBall(&ball,elapsed);
    RenderBall(&ball);

    SDL_RenderPresent(renderer);

}
// s�k�nt� halinde kapatma
void Shutdown(void)
{
    if(renderer)
    {
        SDL_DestroyRenderer(renderer);
    }
    if(window)
    {
        SDL_DestroyWindow(window);
    }

    SDL_Quit();
}
//rastgele de�er g�nderme
bool CoinFlip(void)
{
    return rand() % 2 == 1 ? true : false;
}
//topun yap�ld��� k�s�m
Ball MakeBall(int size)
{
    const float SPEED = 120;
    Ball ball ={
        .x = WIDTH / 2 - size / 2,
        .y = HEIGHT / 2 - size /2,
        .size = size,
        .xSpeed = SPEED * (CoinFlip()? 1 : -1),
        .ySpeed = SPEED * (CoinFlip()? 1 : -1),
    };
    return ball;
}
//topun rengi ve botu
void RenderBall(const Ball *ball)
{
    int size = ball->size;
    int halfSize = size / 2;
    SDL_Rect rect={
        .x = ball->x-halfSize,
        .y = ball->y-halfSize,
        .w = size,
        .h = size,
    };
    SDL_SetRenderDrawColor(renderer,255,255,255,255);
    SDL_RenderFillRect(renderer,&rect);
}
//topun hareketlerini g�ncelleme
void UpdateBall(Ball *ball, float elapsed)
{
    if(!served)
    {
        ball->x = WIDTH / 2;
        ball->y = HEIGHT / 2;
        return;
    }

    ball->x += ball->xSpeed * elapsed;
    ball->y += ball->ySpeed * elapsed;
    if(ball->x < BALL_SIZE / 2)
    {
        ball->xSpeed = fabs(ball->xSpeed);
    }
    if(ball->x > WIDTH - BALL_SIZE / 2)
    {
        ball->xSpeed = -fabs(ball->xSpeed);
    }
    if(ball->y < BALL_SIZE / 2)
    {
        ball->ySpeed = fabs(ball->ySpeed);
    }
    if(ball->y > HEIGHT - BALL_SIZE / 2)
    {
        UpdateScore(2,250);
    }
}
//oyuncu tasar�m�
Player MakePlayer(void)
{
    Player player ={
        .xPosition = WIDTH / 2,
    };
    return player;
}
//oyuncunun hareket etmesi
void UpdatePlayers(float elapsed)
{
    const Uint8 *keyboardState = SDL_GetKeyboardState(NULL);

    if(keyboardState[SDL_SCANCODE_SPACE])
    {
        served = true;
    }
    if (keyboardState[SDL_SCANCODE_A])
    {
        player1.xPosition -= PLAYER_MOVE_SPEED * elapsed;
    }
    if (keyboardState[SDL_SCANCODE_D])
    {
        player1.xPosition += PLAYER_MOVE_SPEED * elapsed;
    }
    if (keyboardState[SDL_SCANCODE_LEFT])
    {
        player1.xPosition -= PLAYER_MOVE_SPEED * elapsed;
    }
    if (keyboardState[SDL_SCANCODE_RIGHT])
    {
        player1.xPosition += PLAYER_MOVE_SPEED * elapsed;
    }

    if(player1.xPosition < PLAYER_WIDTH / 2)
    {
        player1.xPosition = PLAYER_WIDTH / 2;
    }
    if(player1.xPosition > WIDTH - PLAYER_WIDTH / 2)
    {
        player1.xPosition = WIDTH - PLAYER_WIDTH / 2;
    }


    SDL_Rect ballRect={
        .x = ball.x - ball.size / 2,
        .y = ball.y - ball.size / 2,
        .w = ball.size,
        .h = ball.size,
    };
    SDL_Rect player1Rect ={
        .y = HEIGHT - PLAYER_HEIGHT - PLAYER_MARGIN,
        .x = (int)(player1.xPosition) - PLAYER_WIDTH / 2,
        .w = PLAYER_WIDTH,
        .h = PLAYER_HEIGHT,
    };
    SDL_Rect brick1Rect = {
        .x = BRICK_MARGIN,
        .y = (int)(brick1.xPosition)+50 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_Rect brick2Rect = {
        .x = BRICK_MARGIN + 150,
        .y = (int)(brick1.xPosition)+50 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_Rect brick3Rect = {
        .x = BRICK_MARGIN + 300,
        .y = (int)(brick1.xPosition)+50 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
     };
    SDL_Rect brick4Rect = {
        .x = BRICK_MARGIN,
        .y = (int)(brick1.xPosition)+150 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
     };
    SDL_Rect brick5Rect = {
        .x = BRICK_MARGIN+150,
        .y = (int)(brick1.xPosition)+150 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_Rect brick6Rect = {
        .x = BRICK_MARGIN+300,
        .y = (int)(brick1.xPosition)+150 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_Rect brick7Rect = {
        .x = BRICK_MARGIN,
        .y = (int)(brick1.xPosition)+250 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_Rect brick8Rect = {
        .x = BRICK_MARGIN+150,
        .y = (int)(brick1.xPosition)+250 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_Rect brick9Rect = {
        .x = BRICK_MARGIN+300,
        .y = (int)(brick1.xPosition)+250 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    //topun oyuncuya veya tu�lalara �arpmas� durumlar�
    if(SDL_HasIntersection(&ballRect, &player1Rect))
    {
        ball.ySpeed = -fabs(ball.ySpeed);

    }
    if(SDL_HasIntersection(&ballRect, &brick1Rect))
    {
        static int i=1;
        if(i == 1 || i == 2)
        {
            if(ball.y < brick1Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick1Rect.y)
            {
                ball.ySpeed = fabs(ball.ySpeed+27);
                UpdateScore(1,50);
            }
            if(ball.x < brick1Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick1Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
            i++;
            renk1 = renk1-127.5;
        }



    }
    if(SDL_HasIntersection(&ballRect, &brick2Rect))
    {
        static int h=1;
        if(h == 1 || h == 2)
        {
            if(ball.y < brick2Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick2Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick2Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick2Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
        h++;
        renk2 = renk2 - 127.5;
        }


    }
    if(SDL_HasIntersection(&ballRect, &brick3Rect))
    {
        static int g=1;
        if(g == 1 || g == 2)
        {
            if(ball.y < brick3Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick3Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick3Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick3Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
            g++;
            renk3 = renk3-127.5;
        }


    }
    if(SDL_HasIntersection(&ballRect, &brick4Rect))
    {
        static int f=1;
        if(f == 1)
        {
            if(ball.y < brick4Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick4Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick4Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick4Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
        }
        f = 0;
        renk4 = 0;

    }
    if(SDL_HasIntersection(&ballRect, &brick5Rect))
    {
        static int e=1;
        if(e == 1)
        {
            if(ball.y < brick5Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick5Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick5Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick5Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
        }
        e = 0;
        renk5 = 0;

    }
    if(SDL_HasIntersection(&ballRect, &brick6Rect))
    {
        static int d=1;
        if(d == 1)
        {
            if(ball.y < brick6Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick6Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick6Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick6Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
        }
        d = 0;
        renk6 = 0;

    }
    if(SDL_HasIntersection(&ballRect, &brick7Rect))
    {
        static int c=1;
        if(c == 1)
        {
            if(ball.y < brick7Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick7Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick7Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick7Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
        }
        c = 0;
        renk7 = 0;
    }
    if(SDL_HasIntersection(&ballRect, &brick8Rect))
    {
        static int b=1;
        if(b == 1)
        {
            if(ball.y < brick8Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick8Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick8Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x >= brick8Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }
        }
        b = 0;
        renk8 = 0;
    }
    if(SDL_HasIntersection(&ballRect, &brick9Rect))
    {
        static int a=1;
        if(a == 1)
        {
            if(ball.y < brick9Rect.y)
            {
                ball.ySpeed = -fabs(ball.ySpeed);
                UpdateScore(1,50);
            }

            else if(ball.y >= brick9Rect.y+27)
            {
                ball.ySpeed = fabs(ball.ySpeed);
                UpdateScore(1,50);
            }
            if(ball.x < brick9Rect.x)
            {
                ball.xSpeed = -fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

            else if(ball.x > brick9Rect.x+97)
            {
                ball.xSpeed = fabs(ball.xSpeed);
                UpdateScore(1,50);
            }

        }
        a = 0;
        renk9 = 0;
    }

}
//oyuncunnun rengi ve konumunun i�lenmesi
void RenderPlayers(void)
{
    SDL_SetRenderDrawColor(renderer,255,0,0,255);
    SDL_Rect player1Rect ={
        .y = HEIGHT - PLAYER_HEIGHT - PLAYER_MARGIN,
        .x = (int)(player1.xPosition) - PLAYER_WIDTH / 2,
        .w = PLAYER_WIDTH,
        .h = PLAYER_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &player1Rect);
}
//skor tablosu
void UpdateScore(int player, int points)
{

    if(player==1){
        player1.score += points;
    }
     if(player==2){
        served = false;
        player1.score -= points;
    }
    char *fmt ="Skor %d";
    int len = snprintf(NULL,0,fmt,player1.score);
    char buf [len+1];
    snprintf(buf,len+1,fmt,player1.score);
    SDL_SetWindowTitle(window,buf);
}
//tuplalar�n yap�m�
Brick MakeBrick(void)
{
    Brick brick = {
        .xPosition = BRICK_MARGIN,
    };
    return brick;
}
void UpdateBrick(float elapsed)
{

}
//tu�lalar�n rengi ve konumunun i�lenmesi
void RenderBrick(void)
{


    SDL_SetRenderDrawColor(renderer,0,0,renk1,renk1);
    SDL_Rect brick1Rect = {
        .x = BRICK_MARGIN,
        .y = (int)(brick1.xPosition)+50 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick1Rect);

    SDL_SetRenderDrawColor(renderer,0,0,renk2,renk2);
    SDL_Rect brick2Rect = {
        .x = BRICK_MARGIN + 150,
        .y = (int)(brick1.xPosition)+50 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick2Rect);

    SDL_SetRenderDrawColor(renderer,0,0,renk3,renk3);
    SDL_Rect brick3Rect = {
        .x = BRICK_MARGIN + 300,
        .y = (int)(brick1.xPosition)+50 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick3Rect);

    SDL_SetRenderDrawColor(renderer,0,renk4,renk4,renk4);
    SDL_Rect brick4Rect = {
        .x = BRICK_MARGIN,
        .y = (int)(brick1.xPosition)+150 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick4Rect);

    SDL_SetRenderDrawColor(renderer,0,renk5,renk5,renk5);
    SDL_Rect brick5Rect = {
        .x = BRICK_MARGIN+150,
        .y = (int)(brick1.xPosition)+150 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick5Rect);

    SDL_SetRenderDrawColor(renderer,0,renk6,renk6,renk6);
    SDL_Rect brick6Rect = {
        .x = BRICK_MARGIN+300,
        .y = (int)(brick1.xPosition)+150 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick6Rect);

    SDL_SetRenderDrawColor(renderer,renk7,0,renk7,renk7);
    SDL_Rect brick7Rect = {
        .x = BRICK_MARGIN,
        .y = (int)(brick1.xPosition)+250 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick7Rect);

    SDL_SetRenderDrawColor(renderer,renk8,0,renk8,renk8);
    SDL_Rect brick8Rect = {
        .x = BRICK_MARGIN+150,
        .y = (int)(brick1.xPosition)+250 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick8Rect);

    SDL_SetRenderDrawColor(renderer,renk9,0,renk9,renk9);
    SDL_Rect brick9Rect = {
        .x = BRICK_MARGIN+300,
        .y = (int)(brick1.xPosition)+250 - BRICK_WIDTH /2,
        .w = BRICK_WIDTH,
        .h = BRICK_HEIGHT,
    };
    SDL_RenderFillRect(renderer, &brick9Rect);
}
#endif // GAME_H_INCLUDED
