BRİCK BREAKER GAME

Bu tuğla kırma oyunu, C programlama dili ve SDL kitaplığı ile Oğuzcan Özdemirel tarafından kodlanmıştır.

Nasıl Oynanır?
1-Oyunu açtıktan sonra karşınızda 9 adet tuğla, 1 adet top ve bir adet de raket çıkıyor.
2-Kullanıcı boşluk tuşuna bastığında oyun başlar ve top hareket etmeye başlar.
3-Kullanıcı A veya sol ok tuşu ile raketi sola hareket ettirir.
4-Kullanıcı D veya sağ ok tuşu ile raketi sağa hareket ettirir.
5-Skor tablosu sağ üst tarafta yer almaktadır.
6-Çarpılan ve kırılan tuğla başına 100 puan kazanılmaktadır.
7-Tutulamayan toplar 250 puan kaybettirmektedir.
8-Top tutulamadığında devam etmek için boşluk tuşuna basılmalıdır.


Koddaki Hatalar ve Zorluklar
1-Oyun bittiğinde bittiğine dair bir bildirim alınmıyor.

